﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeSort
{
    class TempTransactionRecord : Record
    {
        private string foreignKey;

        public string ForeignKey { get => foreignKey; set => foreignKey = value; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeSort
{
    public class Record
    {
        private string primaryKey;
        private string lastName;
        private string firstName;
        private decimal accountBalance;

        public string PrimaryKey { get => primaryKey; set => primaryKey = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public decimal AccountBalance { get => accountBalance; set => accountBalance = value; }


    }
}

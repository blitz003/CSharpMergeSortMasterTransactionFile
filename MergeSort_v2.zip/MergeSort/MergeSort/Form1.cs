﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace MergeSort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        StreamReader oldMasterFile;
        StreamReader transactionFile;
        StreamWriter newMasterFile;

        List<Record> MasterRecordList = new List<Record>();

        string inLine = "";

        /**
        string primaryKey = "";
        string lastName = "";
        string firstName = "";
        string accountBalance = "";
        **/

        int[] arr = { 12, 11, 13, 5, 6, 7 };

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                A100Initialize();
                A200Process();
                
                DoSomething();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void A100Initialize()
        {
            try
            {
                InputOldMasterCSV();
                InputTransactionCSV();
                OutputNewMasterCSV();
                OutputErrorReportLog();
                OutputValidTransactionLog();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void A200Process()
        {
            try
            {
                int length = MasterRecordList.Count();
                
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void OutputNewMasterCSV()
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void OutputErrorReportLog()
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void OutputValidTransactionLog()
        {
            try
            {

            }
            catch (Exception)
            {

                throw;
            }
        }


        private void InputOldMasterCSV()
        {
            try
            {
                oldMasterFile = File.OpenText("MASTERCSV.csv");

                while (!oldMasterFile.EndOfStream)
                {
                    Record record = new Record();
                    inLine = oldMasterFile.ReadLine();
                    string[] oldMasterFileArray = inLine.Split(',');
                    record.PrimaryKey = oldMasterFileArray[0];
                    record.LastName = oldMasterFileArray[1];
                    record.FirstName = oldMasterFileArray[2];
                    record.AccountBalance = decimal.Parse(oldMasterFileArray[3]);

                    MasterRecordList.Add(record);
                    MessageBox.Show(record.AccountBalance.ToString("C"));

                    //TransferTempArrayToNewArray();
                }

                
            }
            catch (Exception)
            {

                throw;
            }
        }



        private void InputTransactionCSV()
        {
            Record[] NewMasterFileArray = MasterRecordList.ToArray();
            try
            {
                transactionFile = File.OpenText("TRANSACTIONCSV.csv");
                while (!transactionFile.EndOfStream)
                {

                    TempTransactionRecord transactionRecord = new TempTransactionRecord();
                    inLine = transactionFile.ReadLine();
                    string[] transactionFileArray = inLine.Split(',');

                    transactionRecord.ForeignKey = transactionFileArray[0];

                    // make a local int to check if the primary key exists.
                    //string primaryKeyToCheck = transactionRecord.PrimaryKey;
                    //
                    //{
                    //
                    //}
                    transactionRecord.LastName = transactionFileArray[1];
                    transactionRecord.FirstName = transactionFileArray[2];
                    transactionRecord.AccountBalance = decimal.Parse(transactionFileArray[3]);

                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void DoSomething()
        {
            try
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    MessageBox.Show("Given Array: " + arr[i].ToString());
                }

                MergeSort ob = new MergeSort();
                ob.sort(arr, 0, arr.Length - 1);


                MessageBox.Show("Given array complete. Now showing sorted array.");


                for (int i = 0; i < arr.Length; i++)
                {
                    MessageBox.Show("Sorted Array: " + arr[i].ToString());
                }
               

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
